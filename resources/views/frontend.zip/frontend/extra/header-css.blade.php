{{-- <link rel="shortcut icon" href="{{url('front-theme/images/favicon.ico')}}"> --}}

<!-- CSS StyleSheets -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800&amp;amp;subset=latin,latin-ext">
<link rel="stylesheet" href="{{url('front-theme/css/font-awesome.min.css')}}">
<link rel="stylesheet" href="{{url('front-theme/css/animate.css')}}">


<link rel="stylesheet" href="{{url('front-theme/css/style.css')}}">
<link rel="stylesheet" href="{{url('front-theme/css/responsive.css')}}">
<link rel="stylesheet" href="{{url('front-theme/css/skins/default.css')}}">