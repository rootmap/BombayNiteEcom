<div class="login-box">
                <a class="close-login" href="#"><i class="fa fa-times"></i></a>
                <form>
                    <div class="container">
                        <p>Hello our valued visitor, We present you the best web solutions and high quality graphic designs with a lot of features. just login to your account and enjoy ...</p>
                        <div class="login-controls">
                            <div class="skew-25 input-box left">
                                <input type="text" class="txt-box skew25" placeholder="User name Or Email" />
                            </div>
                            <div class="skew-25 input-box left">
                                <input type="password" class="txt-box skew25" placeholder="Password" />
                            </div>
                            <div class="left skew-25 main-bg">
                                <input type="submit" class="btn skew25" value="Login" />
                            </div>
                            <div class="check-box-box">
                                <input type="checkbox" class="check-box" /><label>Remember me !</label>
                                <a href="#">Forgot your password ?</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>